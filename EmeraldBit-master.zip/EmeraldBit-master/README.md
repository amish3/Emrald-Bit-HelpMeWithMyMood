# EmeraldBit

Help me with my Mood

**Tweet:-** I may look calm, but in my head I've killed you about 5 times.
            
**Mood Detected:-** Tentative

**Suggestion:-** Motivational Quote

**Description**

With the advances in technology about sentiment analysis and predictive analytics, it has opened many avenues for researchers and enterprises to understand human mental state better. We analyze the moods of persons based on their tweets. For eg:-

Though analyzing the mood is intricated task nowadays but we have endevaour to detect human mood by using IBM watson tone analyzer tool.

We have classified moods in seven categories:-

1.Analytical 

2.Anger 

3.Confident 

4.Fear 

5.Joy 

6.Sad 

7.Tentative

Based on above categories we have suggested measures to soothe or calm down the mood of the person by suggesting some multimedia like songs/images/videos and some suggestions,jokes.

**How it works**

• Take user handle as input. 

• Extract daily tweets from twitter account.

• Passing them to ibm watson tone analyzer. 

• Analyzes mood of that person.

• Suggestion given according to the mood.

• Also stores previous date mood from the data application is installed.

**Applications**

• Can play a major role in improving one’s health. 

• Encouraging person by providing him motivational quote according to mood. 

• To overcome from the negative moods.

• Organisations can detect that which customer are satisfied & which aren’t with their service & organisation can do best for them. 

• Can act as a psycologist.

**Future Work**

• We will be including speech to text module & passing that resultant text in machine learning algorithms so that it can also detect sarcasm, since it is not neccesary that a person in angry mood may always speak in high pitch. Since IBM Watson doesn’t have sarcasm detector therefore we will try to include above module.

• Extracting text from the images module will also be include so that we came to know about a person’s mood through the images posted on social media.

Including the above set module in our current application we can use it in following ways:-

• Feedback for example in call centres, company’s product & services. 

• In palacement preparation program. 

• Recording real time voice in our app to prevent life hazards accidents by calling to some emergence number. 

• Analyze daily rotine activity of a person through talk
